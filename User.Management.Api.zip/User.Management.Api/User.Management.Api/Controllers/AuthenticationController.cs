﻿using Azure.Messaging;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Org.BouncyCastle.Crypto.Macs;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using User.Management.Api.Models;
using User.Management.Service.Models;
using User.Management.Service.Services;

namespace User.Management.Api.Controllers
{
    //public class AuthenticationController : ControllerBase
    //{
    [Route("api/[controller]")]
        [ApiController]
        public class AuthenticateController : ControllerBase
        {
            private readonly UserManager<IdentityUser> _userManager;
            private readonly RoleManager<IdentityRole> _roleManager;
            private readonly IConfiguration _configuration;
        private readonly IEmailService _emailService;

            public AuthenticateController(
                UserManager<IdentityUser> userManager,
                RoleManager<IdentityRole> roleManager,
                IConfiguration configuration,
                IEmailService emailService
                )
            {
            _emailService = emailService;
                _userManager = userManager;
                _roleManager = roleManager;
                _configuration = configuration;
            }

         
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] SignUp model ,string role)
            {
                var userExists = await _userManager.FindByNameAsync(model.Username);
                if (userExists != null)
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });

                IdentityUser user = new()
                {
                    Email = model.Email,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    UserName = model.Username
                };
            if(await _roleManager.RoleExistsAsync(role))
            {
                var result = await _userManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response
                    {
                        Status = "Error",
                        Message = "User cannot be created"
                    });

                }
                  await  _userManager.AddToRoleAsync(user,role);

               


          var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                //              var confirmationLink = Url.Action(
                //    nameof(ConfirmEmail),
                //    "Authentication",
                //    new { token, email = user.Email },
                //    Request.Scheme
                //);

                var confirmationLink = Url.Link("ConfirmEmailRoute", new { token, email = user.Email });


                var message =new Message(new string[] {user.Email!}, "confirmation email link", confirmationLink!);
                _emailService.sendEmail(message);

                return StatusCode(StatusCodes.Status200OK, new Response
                {
                    Status = "Success",
                    Message = $"user created successfully {user.Email}"
                });
            }

            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Response
                {
                    Status = "Error",
                    Message = "Role doesnt exist"
                });
                //return Ok(new Response { Status = "failed", Message = "User not created successfully!" });
            }


        }

        [HttpGet("ConfirmEmail")]
        public async Task<IActionResult> ConfirmEmail(string token , string email)
        { 
            var user = await _userManager.FindByEmailAsync(email);
            if (user != null)
            {
                var result = await _userManager.ConfirmEmailAsync(user, token);
                if (result.Succeeded)
                {
                    return StatusCode(StatusCodes.Status200OK, new Response
                    {
                        Status = "success",
                        Message = "success"
                    });
                }
            }
            return StatusCode(StatusCodes.Status500InternalServerError, new Response
            {
                Status = "error",
                Message = "error"
            });

           
        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] Login LoginUser)
        {
           var user = await _userManager.FindByNameAsync(LoginUser.Username);
            if (user!=null && await _userManager.CheckPasswordAsync(user,LoginUser.Password))
            {
                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                };
                var userRoles = await _userManager.GetRolesAsync(user);
                foreach(var role in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, role));
                }
                var jwtToken = GetToken(authClaims);
                return Ok(new { 
                token = new JwtSecurityTokenHandler().WriteToken(jwtToken),
                expiration=jwtToken.ValidTo
                });
            }
            return Unauthorized();
        }
    

        private JwtSecurityToken GetToken(List<Claim> authClaims)
        {
            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));
            var token = new JwtSecurityToken(

        issuer: _configuration["JWT:ValidAudience"],
        audience: _configuration["JWT:ValidIssuer"],
        expires: DateTime.Now.AddHours(3),
        claims: authClaims,
        signingCredentials:  new SigningCredentials(authSigningKey,SecurityAlgorithms.HmacSha256)
                );

            return token;

        }
    }
  
}
