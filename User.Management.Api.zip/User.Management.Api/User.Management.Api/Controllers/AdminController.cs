﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace User.Management.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
       [HttpGet("employees")]
        public IEnumerable<string> Get()
        {
            return new List<string> { "tatsam","ram","hari"};
        }
    }
}
