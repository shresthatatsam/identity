﻿
using User.Management.Service.Models;

namespace User.Management.Service.Services
{
    public interface IEmailService
    {
        //Task SendEmailAsync(string email, string subject, string message);
        void sendEmail(Message message);
    }
}
