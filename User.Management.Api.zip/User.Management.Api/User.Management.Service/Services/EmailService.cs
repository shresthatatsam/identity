﻿using MailKit.Net.Smtp;
using MimeKit;
using User.Management.Service.Models;

namespace User.Management.Service.Services
{
    public class EmailService : IEmailService
    {

        private readonly EmailConfiguration _emailConfiguration;
        public EmailService(EmailConfiguration emailConfiguration)
        {
            _emailConfiguration = emailConfiguration;
        }

        //public Task SendEmailAsync(string email, string subject, string message)
        //{
        //    var mail = "tatsam.shrestha93@gmail.com";
        //    var password = "Iphone123!@#";

        //    var client = new System.Net.Mail.SmtpClient("smtp-mail.outlook.com", 587)
        //    {
        //        EnableSsl = true,
        //        Credentials = new NetworkCredential(mail, password)
        //    };

        //    return client.SendMailAsync(
        //        new MailMessage(
        //            from: mail,
        //            to: email,
        //            subject, message));

        //}

       public void sendEmail(Message message)
       {
           var emailMessage = createEmailMessage(message);
           Send(emailMessage);
       }

       private MimeMessage createEmailMessage(Message message)
       {
           var emailMessage = new MimeMessage();
           emailMessage.From.Add(new MailboxAddress("email", _emailConfiguration.From));
           emailMessage.To.AddRange(message.To);
           emailMessage.Subject= message.Subject==null?"test":message.Subject;
           emailMessage.Body=new TextPart(MimeKit.Text.TextFormat.Text) { Text = message.Content};
           return emailMessage;
       }

       private void Send(MimeMessage mailmessage)
       {
           using var client = new SmtpClient();

           try
           {

               client.Connect(_emailConfiguration.SmtpServer, _emailConfiguration.Port, true);

               client.AuthenticationMechanisms.Remove("XOAUTH2");

               client.Authenticate(_emailConfiguration.UserName, _emailConfiguration.Password);


               client.Send(mailmessage);



           }
           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               client.Disconnect(true);
               client.Dispose();
           }
       }

    }
}
